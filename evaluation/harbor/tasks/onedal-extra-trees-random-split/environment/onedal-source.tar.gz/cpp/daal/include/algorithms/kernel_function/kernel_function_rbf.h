/* file: kernel_function_rbf.h */
/*******************************************************************************
* Copyright 2014 Intel Corporation
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

/*
//++
//  Implementation of the interface for the radial basis function (RBF) kernel algorithm
//--
*/

#ifndef __KERNEL_FUNCTION_RBF_H__
#define __KERNEL_FUNCTION_RBF_H__

#include "algorithms/algorithm.h"
#include "data_management/data/numeric_table.h"
#include "algorithms/kernel_function/kernel_function_types_rbf.h"
#include "algorithms/kernel_function/kernel_function.h"

namespace daal
{
namespace algorithms
{
namespace kernel_function
{
namespace rbf
{
namespace interface1
{
/**
 * @defgroup kernel_function_rbf_batch Batch
 * @ingroup kernel_function_rbf
 * @{
 */
/**
 * <a name="DAAL-CLASS-ALGORITHMS__KERNEL_FUNCTION__RBF__BATCH"></a>
 * \brief Computes the RBF kernel function in the batch processing mode.
 * <!-- \n<a href="DAAL-REF-KERNEL_FUNCTION_RBF-ALGORITHM">Kernel function algorithm description and usage models</a> -->
 *
 * \tparam algorithmFPType  Data type to use in intermediate computations of kernel functions, double or float
 * \tparam method           Computation method of the algorithm, \ref Method
 *
 * \par Enumerations
 *      - \ref Method   Methods for computing  kernel functions
 *      - \ref InputId  Identifiers of input objects for the kernel function algorithm
 *      - \ref ResultId Identifiers of results of the kernel function algorithm
 *
 * \par References
 *      - \ref interface1::Result "Result" class
 *
 * \DAAL_DEPRECATED
 */
template <typename algorithmFPType = DAAL_ALGORITHM_FP_TYPE, Method method = defaultDense>
class DAAL_EXPORT Batch : public KernelIface
{
public:
    typedef KernelIface super;

    typedef algorithms::kernel_function::rbf::Input InputType;
    typedef algorithms::kernel_function::rbf::Parameter ParameterType;
    typedef typename super::ResultType ResultType;

    ParameterType parameter; /*!< Parameter of the kernel function*/
    InputType input;         /*!< %Input data structure */

    /** Default constructor */
    DAAL_DEPRECATED Batch();

    /**
     * Constructs RBF kernel function algorithm by copying input objects and parameters
     * of another RBF kernel function algorithm
     * \param[in] other An algorithm to be used as the source to initialize the input objects
     *                  and parameters of the algorithm
     */
    Batch(const Batch<algorithmFPType, method> & other);

    /**
    * Returns the method of the algorithm
    * \return Method of the algorithm
    */
    int getMethod() const override { return (int)method; }

    /**
     * Get input objects for the kernel function algorithm
     * \return %Input objects for the kernel function algorithm
     */
    InputType * getInput() override { return &input; }

    /**
     * Get parameters of the kernel function algorithm
     * \return Parameters of the kernel function algorithm
     */
    ParameterBase * getParameter() override { return &parameter; }

    /**
     * Returns a pointer to the newly allocated RBF kernel function algorithm with a copy of input objects
     * and parameters of this RBF kernel function algorithm
     * \return Pointer to the newly allocated algorithm
     */
    services::SharedPtr<Batch<algorithmFPType, method> > clone() const { return services::SharedPtr<Batch<algorithmFPType, method> >(cloneImpl()); }

protected:
    void initialize();
    Batch<algorithmFPType, method> * cloneImpl() const override { return new Batch<algorithmFPType, method>(*this); }

    services::Status allocateResult() override
    {
        services::Status s = _result->allocate<algorithmFPType>(&input, &parameter, (int)method);
        _res               = _result.get();
        return s;
    }

private:
    Batch & operator=(const Batch &);
};
/** @} */
} // namespace interface1
using interface1::Batch;

} // namespace rbf
} // namespace kernel_function
} // namespace algorithms
} // namespace daal
#endif
